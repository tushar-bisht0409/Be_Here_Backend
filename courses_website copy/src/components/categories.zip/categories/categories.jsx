import React from "react";
import "./categories.css";

const categories = () => {
  return (
    <>
      <div className="categoriesContainer">
        <h1>Our Class Categories</h1>
        {/* <button className="btn">
          <i class="fa-solid fa-angle-left"></i>
        </button>
        <button className="btn">
          <i class="fa-solid fa-angle-right"></i>
        </button> */}
        <ul className="categoriesList">
          <li className="listItems">1ListItem</li>
          <li className="listItems">2ListItem</li>
          <li className="listItems">3ListItem</li>
          <li className="listItems">4ListItem</li>
          <li className="listItems">5ListItem</li>
          <li className="listItems">6ListItem</li>
          <li className="listItems">7ListItem</li>
          <li className="listItems">8ListItem</li>
          <li className="listItems">9ListItem</li>
          <li className="listItems">10ListItem</li>
          <li className="listItems">11ListItem</li>
          <li className="listItems">12ListItem</li>
          <li className="listItems">13ListItem</li>
          <li className="listItems">14ListItem</li>
          <li className="listItems">15ListItem</li>
        </ul>
      </div>
    </>
  );
};

export default categories;
